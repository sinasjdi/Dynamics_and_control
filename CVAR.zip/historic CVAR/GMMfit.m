% Original data to fit
X = [0.91,3.55,1.20,2.35,1.58,0.75,6.65,10.22,15.30,19.38,6.98,7.79,3.43,3.68,2.04,1.93,1.03,1.14,2.16,5.65,0.48,0.75,0.28,0.20,0.15,0.20,0.11,0.07,0.05];
xvals = 1:numel(X);
% Define a tri-modal gaussian with 3 independent peaks with 11 parameters:
% b(1) vertical off
% b(2) slope
% b(3) amp1
% b(4) mu1
% b(5) std1
% b(6) amp2
% b(7) mu2
% b(8) std2
% b(9) amp3
% b(10) mu3
% b(11) std3
mixGausMdl = @(b,x) b(1) + b(2) * x(:, 1) + b(3) * exp( -(x(:, 1) - b(4)).^2/(2*b(5)^2)) + b(6) * exp(-(x(:, 1) - b(7)).^2/(2*b(8)^2)) + b(9) * exp(-(x(:, 1) - b(10)).^2/(2*b(11)^2));
% Set initial guesses, lower and upper bounds to each parameter
initGuess =  [0,   0.1,   3,  2,  1.06,  19,  10,  5.88   4    20     1]; 
lowbounds =  [0   -inf    0   0   .1     0     0   0.1    0    20    .1];
highbounds = [0    inf   10   10   10    inf  25   10     6    30    10];
% Poisson log-likelihood; fmincon finds the minimum of this function.  Thus, 
% will find the max of the poisson loglikelihood.
poissonLogLikelihood = @(r,lambda) r(:)'*log(lambda(:)) - sum(lambda);
% loss functions for fitting
nllFcn = @(params) -poissonLogLikelihood(X, mixGausMdl(params, xvals(:)));
% Do fitting
opts = optimset('LargeScale', 'off', 'MaxIter', 50000, 'Display', 'off');
[paramEst, nll, exitflag] = fmincon(nllFcn, initGuess, [], [], [], [], lowbounds, highbounds,[],opts);
% show results
T = table((1:numel(paramEst))',paramEst(:), initGuess(:), lowbounds(:), highbounds(:), ...
    'VariableNames', {'idx','Estimates','initGuess','lowBound','HiBound'}, ...
    'RowNames',{'VertOff','slope','amp1','mu1','std1','amp2','mu2','std2','amp3','mu3','std3'});
disp(T)

% Plot results
clf()
bar(xvals, X, 'FaceColor',[.8 .8 .8])
hold on
% Plot fit
xx = linspace(xvals(1),xvals(end),100);
yy = mixGausMdl(paramEst,xx(:));
plot(xx,yy,'r-','LineWidth',5)
% Show each guassian separately
gaus = @(x,mu,sig,amp,vo)amp*exp(-(((x-mu).^2)/(2*sig.^2)))+vo;
y1 = gaus(xx, paramEst(4), paramEst(5), paramEst(3), paramEst(1)); 
y2 = gaus(xx, paramEst(7), paramEst(8), paramEst(6), paramEst(1)); 
y3 = gaus(xx, paramEst(10), paramEst(11), paramEst(9), paramEst(1)); 
plot(xx,y1, 'c:', 'LineWidth',3)
plot(xx,y2, 'k:', 'LineWidth',3)
plot(xx,y3, 'b:', 'LineWidth',3)





