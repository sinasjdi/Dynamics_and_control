load data

integral=sum(returns);
returns=returns/integral;

returns_sum=cumsum(returns)


plot(returns_sum)
figure

confidence_level = 0.95;
plot_flag = true;
figure
VAR_hist = computeHistoricalVaR(returns,confidence_level,plot_flag);
